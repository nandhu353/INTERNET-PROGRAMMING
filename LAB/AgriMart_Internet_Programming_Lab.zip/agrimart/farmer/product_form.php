<?php
require_once '../includes/functions.php';$u=require_role('farmer');$id=(int)($_GET['id']??$_POST['id']??0);$p=null;
if($id){$s=$pdo->prepare("SELECT * FROM products WHERE id=? AND farmer_id=?");$s->execute([$id,$u['id']]);$p=$s->fetch();if(!$p)exit('Product not found or access denied.');}
if($_SERVER['REQUEST_METHOD']==='POST'){
$name=trim($_POST['name']??'');$cat=trim($_POST['category']??'');$desc=trim($_POST['description']??'');$price=(float)($_POST['price']??0);$stock=(int)($_POST['stock']??0);
try{if(!$name||!$cat||!$desc||$price<=0||$stock<0)throw new RuntimeException('Enter valid product details.');$img=upload_product_image('image');
if($id){$sql="UPDATE products SET name=?,category=?,description=?,price=?,stock=?";$args=[$name,$cat,$desc,$price,$stock];if($img){$sql.=",image=?";$args[]=$img;}$sql.=" WHERE id=? AND farmer_id=?";$args[]=$id;$args[]=$u['id'];$pdo->prepare($sql)->execute($args);if($img&&$p['image']&&is_file(__DIR__.'/../uploads/'.$p['image']))@unlink(__DIR__.'/../uploads/'.$p['image']);}
else{$pdo->prepare("INSERT INTO products(farmer_id,name,category,description,price,stock,image) VALUES(?,?,?,?,?,?,?)")->execute([$u['id'],$name,$cat,$desc,$price,$stock,$img]);}
flash('Product saved successfully.');redirect('products.php');
}catch(Throwable $e){flash($e->getMessage(),'error');}
}
$page_title=$id?'Edit product':'Add product';$base='../';require '../includes/header.php';?>
<div class="form-wrap panel"><h1><?=$id?'Edit product':'Add a product'?></h1><form method="post" enctype="multipart/form-data"><?=csrf_field()?><input type="hidden" name="id" value="<?=$id?>"><label>Product name<input name="name" required value="<?=e($_POST['name']??$p['name']??'')?>"></label><label>Category<select name="category" required><?php foreach(['Seeds','Fertilizers','Pesticides','Farming Equipment','Tools','Irrigation','Other'] as $c):?><option <?=($_POST['category']??$p['category']??'')===$c?'selected':''?>><?=e($c)?></option><?php endforeach;?></select></label><label>Description<textarea name="description" required><?=e($_POST['description']??$p['description']??'')?></textarea></label><div class="row"><label>Price (₹)<input type="number" name="price" min="0.01" step="0.01" required value="<?=e($_POST['price']??$p['price']??'')?>"></label><label>Stock quantity<input type="number" name="stock" min="0" required value="<?=e($_POST['stock']??$p['stock']??'0')?>"></label></div><label>Product image (JPG/PNG/WEBP, max 3 MB)<input type="file" name="image" accept="image/jpeg,image/png,image/webp"></label><?php if(!empty($p['image'])):?><img class="product-img" src="../uploads/<?=e($p['image'])?>" alt="Current product image"><?php endif;?><button>Save product</button></form></div>
<?php require '../includes/footer.php'; ?>
