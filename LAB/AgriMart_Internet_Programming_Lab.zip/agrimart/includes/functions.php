<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../config/database.php';

function e($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function redirect(string $url): never { header("Location: $url"); exit; }
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function csrf_field(): string { return '<input type="hidden" name="csrf" value="'.e(csrf_token()).'">'; }
function verify_csrf(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' &&
        !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(419); exit('Invalid request token. Refresh and try again.');
    }
}
verify_csrf();

function current_user(): ?array { return $_SESSION['user'] ?? null; }
function require_login(): array {
    $u = current_user();
    if (!$u) redirect('login.php');
    if (empty($u['is_verified'])) redirect('verify.php');
    return $u;
}
function require_role(string $role): array {
    $u = require_login();
    if ($u['role'] !== $role) redirect($u['role'] === 'farmer' ? 'farmer/dashboard.php' : 'index.php');
    return $u;
}
function refresh_user(PDO $pdo): void {
    if (!empty($_SESSION['user']['id'])) {
        $s=$pdo->prepare("SELECT id,name,email,phone,role,is_verified,wallet FROM users WHERE id=?");
        $s->execute([$_SESSION['user']['id']]);
        $_SESSION['user']=$s->fetch();
    }
}
function flash(string $message, string $type='success'): void { $_SESSION['flash']=['message'=>$message,'type'=>$type]; }
function show_flash(): void {
    if (!empty($_SESSION['flash'])) {
        $f=$_SESSION['flash']; unset($_SESSION['flash']);
        echo '<div class="alert '.e($f['type']).'">'.e($f['message']).'</div>';
    }
}
function money($amount): string { return '₹'.number_format((float)$amount,2); }
function create_otp(PDO $pdo, int $userId): string {
    $otp=(string)random_int(100000,999999);
    $hash=password_hash($otp,PASSWORD_DEFAULT);
    $expires=date('Y-m-d H:i:s',time()+300);
    $pdo->prepare("UPDATE users SET otp_hash=?,otp_expires_at=? WHERE id=?")->execute([$hash,$expires,$userId]);
    $_SESSION['demo_otp']=$otp; // Local lab demonstration only.
    return $otp;
}
function upload_product_image(string $field): ?string {
    if (empty($_FILES[$field]['name'])) return null;
    $f=$_FILES[$field];
    if ($f['error'] !== UPLOAD_ERR_OK || $f['size'] > 3*1024*1024) throw new RuntimeException('Image must be under 3 MB.');
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    $allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    if (!isset($allowed[$mime])) throw new RuntimeException('Only JPG, PNG and WEBP images are allowed.');
    $name=bin2hex(random_bytes(12)).'.'.$allowed[$mime];
    if (!move_uploaded_file($f['tmp_name'],__DIR__.'/../uploads/'.$name)) throw new RuntimeException('Image upload failed.');
    return $name;
}
