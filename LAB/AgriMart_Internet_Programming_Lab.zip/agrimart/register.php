<?php
require_once 'includes/functions.php'; $page_title='Register'; $base='';
if($_SERVER['REQUEST_METHOD']==='POST'){
$name=trim($_POST['name']??'');$email=strtolower(trim($_POST['email']??''));$phone=trim($_POST['phone']??'');$role=$_POST['role']??'customer';$pw=$_POST['password']??'';
if(!$name||!filter_var($email,FILTER_VALIDATE_EMAIL)||!preg_match('/^[0-9+\-\s]{8,20}$/',$phone)||strlen($pw)<8||!in_array($role,['farmer','customer'])) flash('Enter valid details. Password must be at least 8 characters.','error');
else{
try{$s=$pdo->prepare("INSERT INTO users(name,email,phone,password_hash,role) VALUES(?,?,?,?,?)");$s->execute([$name,$email,$phone,password_hash($pw,PASSWORD_DEFAULT),$role]);$id=(int)$pdo->lastInsertId();$otp=create_otp($pdo,$id);$_SESSION['pending_user']=$id;flash("Registration successful. Demo OTP: $otp",'info');redirect('verify.php');}
catch(PDOException $e){flash('This email is already registered.','error');}
}}
require 'includes/header.php';?>
<div class="form-wrap panel"><h1>Create your account</h1><p class="muted">Register as a farmer or customer.</p><form method="post"><?=csrf_field()?>
<label>Full name<input name="name" required maxlength="120"></label><label>Email<input type="email" name="email" required></label><label>Phone number<input name="phone" required></label><label>Account type<select name="role"><option value="customer">Customer</option><option value="farmer">Farmer</option></select></label><label>Password<input type="password" name="password" minlength="8" required></label><button>Create account</button></form></div>
<?php require 'includes/footer.php'; ?>
