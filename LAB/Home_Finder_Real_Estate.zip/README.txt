HOME FINDER - REAL ESTATE PROPERTY SEARCH WEBSITE
=================================================

HOW TO RUN
1. Extract Home_Finder_Real_Estate.zip.
2. Open index.html in Chrome, Edge or Firefox.
3. No installation is required.

FEATURES
- Search residential and commercial properties, houses, apartments and land.
- Filter by location, property type, buy/rent, budget, bedrooms and parking.
- Save and reload buyer search criteria.
- Detailed property listing cards with price, area, amenities and agent details.
- Google Maps search link for each property location.
- Buyer registration and login.
- Save favourite properties.
- Schedule property viewings and view requests.
- Agent and company directory with enquiry form.
- Mortgage / EMI calculator.
- Admin can add and remove property listings.
- Admin can view registered buyers, website visit records and viewing requests.
- Responsive layout for desktop and mobile.
- Links to other property listing websites.

ADMIN DEMO LOGIN
Email: admin@homefinder.demo
Password: home123

TECHNOLOGIES
HTML, CSS, JavaScript and browser LocalStorage.

IMPORTANT
This is a frontend lab prototype. Data is stored in the current browser using
LocalStorage, not a remote database. Password handling is for demonstration only
and is not secure. Google Maps opens a location search link; no live map API is
embedded. Property photos and virtual tours are represented with demo visuals.
For production, connect a secure backend/database, real property image storage,
Google Maps API, authentication, notification service and agent messaging system.
