# SweetSpot – Online Cake Ordering System

## Run
1. Extract `SweetSpot_Cake_Ordering_System.zip`.
2. Open `index.html` in a modern web browser.
3. Browse cakes, use search and filters, add products to cart, register/login, and place a demo order.

## Demo administrator credentials
- Username: `admin`
- Password: `admin123`

## Student modules included
- Register and Login
- Search Cake
- Filter by category, subcategory/flavour, occasion and price range
- View Cake List
- View Cake Description
- Add to Cart and update quantities
- Place Order
- Add Delivery / Shipping Address
- Update delivery address by placing a new order (editing an existing placed order is not implemented in this demo)
- My Orders / Order History
- View Shipping / Delivery Status
- Admin login
- Add and remove cakes; manage stock
- View customer orders and update delivery status
- Responsive design for desktop, tablet and mobile

## Technologies
HTML5, CSS3, JavaScript and browser LocalStorage.

## Important notes
This is a front-end educational lab prototype. Demo data is saved in browser LocalStorage. It does not connect to a live bakery/GPS location service, real payment gateway, email service or backend database. Payment choices are demonstrations only; no real payment is processed. Password reset and confirmation emails require backend integration. Do not enter real payment details.
