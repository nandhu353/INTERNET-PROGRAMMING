BLOSSOMGifts - ONLINE FLOWERS AND GIFTS STORE

CONTENTS
- index.html: homepage, product catalogue, cart, account and modal screens
- style.css: responsive layout and styling
- app.js: shopping, account, inventory and order logic
- README.txt: setup and demo instructions

HOW TO RUN
1. Extract the ZIP.
2. Open index.html in a modern web browser.
3. Register a customer account or sign in with a demo account.

DEMO ACCOUNTS
Admin: admin@blossom.demo / admin123
Customer: customer@blossom.demo / customer123

CUSTOMER FEATURES
- Register, login and logout
- Browse home page categories and product subcategories
- Search products and filter by category and occasion
- Sort products by price and popularity
- View product descriptions, prices and availability
- Add products to cart, change quantities and remove items
- Checkout with recipient details, delivery address, date and time
- Add a personalized gift message
- View order history and demo order status/tracking
- Submit an inquiry/contact form

ADMIN FEATURES
- Add, edit and delete inventory items
- Change product prices and stock quantities
- View customer checkout and delivery information
- View order summary and total order value

DEMO LIMITATIONS
This is an academic frontend prototype built with HTML, CSS and JavaScript.
Data is saved in browser LocalStorage. Checkout and payment methods are simulated:
no real payment is taken. The inquiry form stores a local demo record; it does not send
email. SMS/email confirmations and live courier tracking are not connected. Product
photos are loaded from remote Unsplash image URLs, so an internet connection is needed
to display those images. For production, connect a secure backend/database, payment
gateway, email/SMS service and courier tracking API.
