VOTEONLINE - INTERNET PROGRAMMING LAB EXPERIMENT

HOW TO RUN
1. Extract VoteOnline.zip.
2. Open the VoteOnline folder.
3. Double-click index.html or open it in a web browser.
4. No installation is required.

DEMO ADMIN LOGIN
Username: admin
Password: admin123

DEMO VOTER LOGIN
Voter ID: VOT1001
The demo OTP is displayed on the screen after selecting Get Login OTP.
The voting OTP is displayed after selecting Get OTP for Voting.

FEATURES
ADMIN
- Create/update election and set election status.
- Create election candidates and allocate candidates to an election.
- Allocate voters to wards/elections.
- Create and view voter list.
- Import voter list from CSV.
- Update or delete voter records.
- View election results and vote counts.

VOTER
- Login using Voter ID.
- OTP login verification.
- View election and candidate details.
- Select candidate.
- Get separate OTP for voting.
- Submit vote and receive confirmation.
- View voting history/status.

IMPORTANT
This is a frontend lab demonstration using HTML, CSS, JavaScript and browser LocalStorage.
OTP values are displayed on screen for demonstration. It does not send real SMS/email OTP.
It is not suitable for real public elections. Real e-voting requires a secure backend,
strong identity verification, cryptographic vote secrecy, independent audits, legal
compliance, accessibility testing and secure infrastructure.
CSV format for import:
voterId,name,ward,election
VOT1002,Sample Voter,Ward 1,General Election 2026
