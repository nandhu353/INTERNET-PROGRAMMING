StayEase — Hotel Room Booking Website (Demo)

HOW TO RUN
1. Extract the ZIP file.
2. Open the hotel_room_booking_website folder.
3. Double-click index.html, or open it in Chrome/Edge.
4. Internet is needed for the room photos and Google Fonts; the website layout and core demo features work locally.

FEATURES
- Responsive room listings with room types, amenities, nightly rates, guest capacity, and availability.
- Destination/date/guest/room-type search.
- User registration, login, profile identity, booking history, booking changes and cancellations.
- Changes and cancellations allowed only at least 3 days before check-in.
- Demo checkout (no real payment is processed).
- Booking references and guest reviews/ratings.
- Admin panel for room quantity/prices, booking edits/cancellations, guest list, and static page content.
- FAQ, contact information, local travel guide, and privacy policy.
- Browser localStorage is used to save demo data.

DEMO ADMIN
Email: admin@stayease.com
Password: admin123

IMPORTANT
This is a front-end academic/demo project, not a production hotel system. Authentication and data are stored in the browser and are not secure. The payment flow is simulated. For real deployment, add a backend API, database, secure password hashing, email service, and a compliant payment gateway.
