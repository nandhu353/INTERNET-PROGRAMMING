# AgriMart - Internet Programming Lab Project

A PHP + MySQL agricultural e-commerce application with farmer and customer roles.

## Requirements
- PHP 8.0+ (PDO, fileinfo enabled)
- MySQL 5.7+ / MariaDB
- Apache (XAMPP/WAMP/LAMP)

## Setup (XAMPP)
1. Copy the `agrimart` folder into `C:\xampp\htdocs\`.
2. Start Apache and MySQL.
3. Open phpMyAdmin and import `database/agrimart.sql`.
4. Edit `config/database.php` if your MySQL username/password differs.
5. Visit `http://localhost/agrimart/`.

## Demo accounts
Create accounts through Register. Select **Farmer** to access the farmer dashboard, or **Customer** for the shopping experience.
For local lab demonstration, OTP is generated and displayed on screen after registration/login. In production, connect an SMS/email OTP provider and remove the demo display.

## Included functionality
- Farmer/customer registration, login, demo OTP verification and logout
- Farmer product add/edit/delete and image upload
- Farmer sales/orders dashboard and shipping status updates
- Customer product search/category filtering and product details
- Cart add/update/remove
- Shipping address create/edit/delete and selection at checkout
- Demo wallet top-up and wallet balance
- Checkout with wallet payment; order and stock updates
- Customer order and shipment status tracking
- CSRF protection, password hashing, prepared SQL statements and upload validation

## Notes
- This is a lab-ready local demonstration. Wallet top-up is simulated; no real payment gateway is connected.
- OTP is displayed for demonstration only; do not deploy this configuration publicly.
- Change the default database credentials and use HTTPS before any real deployment.
