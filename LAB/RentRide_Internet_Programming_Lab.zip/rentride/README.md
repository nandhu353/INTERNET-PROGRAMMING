# RentRide - Internet Programming Lab Project

PHP + MySQL + HTML + CSS + JavaScript vehicle rental and appointment booking application.

## Requirements
- PHP 8+ with PDO and fileinfo
- MySQL 5.7+ or MariaDB
- Apache (XAMPP/WAMP/LAMP)

## XAMPP setup
1. Extract the ZIP.
2. Copy `rentride` into `C:\xampp\htdocs\`.
3. Start Apache and MySQL.
4. Import `database/rentride.sql` using phpMyAdmin.
5. Check database credentials in `config/database.php`.
6. Open `http://localhost/rentride/`.

## First admin account
Register a normal account, then run this SQL in phpMyAdmin, replacing the email:
`UPDATE users SET role='admin', is_verified=1 WHERE email='admin@example.com';`
Log in with that account. Admin login is role-protected.

## Features
- User registration, login, demo OTP verification and profile
- Vehicle search by type, location, dates and price range
- Vehicle detail pages with images and rental pricing
- Booking request with customer name, phone and address
- Admin vehicle add/edit/delete and booking approval/rejection
- Booking check-in form and appointment time scheduling
- User booking status, past booking history and reviews
- Admin dashboard and booking management

## Demo limitations
- OTP is displayed on screen for local lab testing; connect a real SMS/email service for production.
- Payment is recorded as a demo reservation payment status; no real payment gateway is connected.
- Admin role is assigned through the SQL instruction above.
