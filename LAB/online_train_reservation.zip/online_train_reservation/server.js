const express = require("express");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const trains = [
  { id: 12001, name: "Chennai Express", from: "Chennai", to: "Bengaluru", departure: "06:00", arrival: "11:00", classes: ["Sleeper", "AC 3 Tier", "AC 2 Tier"], seats: 42, fare: 450 },
  { id: 12625, name: "Kerala Express", from: "Chennai", to: "Kochi", departure: "08:30", arrival: "17:15", classes: ["Sleeper", "AC 3 Tier"], seats: 28, fare: 620 },
  { id: 12658, name: "Bengaluru Mail", from: "Bengaluru", to: "Chennai", departure: "22:30", arrival: "04:45", classes: ["Sleeper", "AC 3 Tier", "AC 2 Tier"], seats: 35, fare: 500 },
  { id: 12603, name: "Hyderabad Express", from: "Chennai", to: "Hyderabad", departure: "19:10", arrival: "07:00", classes: ["Sleeper", "AC 3 Tier"], seats: 19, fare: 700 }
];
const bookings = [];
const users = [];

app.get("/api/trains", (req, res) => {
  const { from, to } = req.query;
  const result = trains.filter(t =>
    (!from || t.from.toLowerCase() === from.toLowerCase()) &&
    (!to || t.to.toLowerCase() === to.toLowerCase())
  );
  res.json(result);
});

app.post("/api/register", (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) return res.status(400).json({ error: "Please fill in all fields." });
  if (users.some(u => u.email === email)) return res.status(409).json({ error: "Email is already registered." });
  users.push({ name, email, password });
  res.json({ message: "Registration successful. You can now log in." });
});

app.post("/api/login", (req, res) => {
  const { email, password } = req.body;
  const user = users.find(u => u.email === email && u.password === password);
  if (!user) return res.status(401).json({ error: "Invalid credentials. Register first in this demo." });
  res.json({ name: user.name, email: user.email });
});

app.post("/api/bookings", (req, res) => {
  const { passenger, email, trainId, travelDate, travelClass, seats } = req.body;
  const train = trains.find(t => t.id === Number(trainId));
  if (!train || !passenger || !email || !travelDate || !travelClass || !Number.isInteger(Number(seats)) || Number(seats) < 1) {
    return res.status(400).json({ error: "Please provide valid booking details." });
  }
  if (!train.classes.includes(travelClass)) return res.status(400).json({ error: "Class is not available for this train." });
  const count = Number(seats);
  if (count > train.seats) return res.status(400).json({ error: "Not enough seats available." });
  train.seats -= count;
  const booking = {
    pnr: String(Math.floor(1000000000 + Math.random() * 9000000000)),
    passenger, email, trainId: train.id, trainName: train.name, from: train.from, to: train.to,
    travelDate, travelClass, seats: count, fare: train.fare * count, status: "Confirmed"
  };
  bookings.push(booking);
  res.json(booking);
});

app.get("/api/bookings/:pnr", (req, res) => {
  const booking = bookings.find(b => b.pnr === req.params.pnr);
  if (!booking) return res.status(404).json({ error: "PNR not found." });
  res.json(booking);
});

app.post("/api/cancel", (req, res) => {
  const booking = bookings.find(b => b.pnr === String(req.body.pnr));
  if (!booking) return res.status(404).json({ error: "PNR not found." });
  if (booking.status === "Cancelled") return res.status(400).json({ error: "This booking is already cancelled." });
  booking.status = "Cancelled";
  const train = trains.find(t => t.id === booking.trainId);
  if (train) train.seats += booking.seats;
  booking.refund = Math.round(booking.fare * 0.8);
  res.json({ message: "Ticket cancelled. Demo refund amount calculated at 80%.", refund: booking.refund, booking });
});

app.listen(PORT, () => console.log(`Train Reservation demo running at http://localhost:${PORT}`));
