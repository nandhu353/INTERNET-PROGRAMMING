INSUREEASY - INSURANCE MANAGEMENT WEBSITE

FILES
- index.html: website structure and login/register screens
- style.css: responsive interface styling
- app.js: demo application logic and LocalStorage data

HOW TO RUN
1. Extract the ZIP file.
2. Open index.html in a modern browser.
3. Register as a customer or agent, or use the demo accounts below.

DEMO ACCOUNTS
Administrator: admin@insureeasy.demo / admin123
Customer: customer@insureeasy.demo / customer123
Agent: agent@insureeasy.demo / agent123

MAIN FEATURES
ADMIN
- Administrator login
- Approve agent registrations
- View agent details and customer directory
- View and remove policy records
- Review and approve policy applications
- Review and resolve claims
- View platform activity

AGENT
- Agent registration (requires administrator approval)
- Agent login
- Create customer accounts
- View and manage assigned customer details
- Add customer policies
- Create renewal/payment SMS reminder records
- View customer applications and claims

CUSTOMER
- Customer registration and login
- Compare Health, Auto and Home insurance plans
- View policy information and coverage
- Submit policy applications
- View and manage policy records
- Record a simulated premium payment
- File and track claims
- View in-app renewal/payment alerts
- View profile

IMPORTANT DEMO LIMITATIONS
This is a frontend academic project prototype built with HTML, CSS and JavaScript.
Data is stored in the browser's LocalStorage. It is not a production application and
does not include a secure server/database, real SMS gateway, real payment processing,
identity verification, or legally binding insurance purchases. Demo policy prices and
coverage values are illustrative only. For real deployment, add a backend, authentication,
database, payment provider and SMS gateway, and follow applicable insurance regulations.
