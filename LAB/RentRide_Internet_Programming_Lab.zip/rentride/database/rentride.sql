CREATE DATABASE IF NOT EXISTS rentride CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE rentride;

CREATE TABLE IF NOT EXISTS users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 phone VARCHAR(25) NOT NULL,
 password_hash VARCHAR(255) NOT NULL,
 role ENUM('user','admin') NOT NULL DEFAULT 'user',
 is_verified TINYINT(1) NOT NULL DEFAULT 0,
 otp_hash VARCHAR(255) DEFAULT NULL,
 otp_expires_at DATETIME DEFAULT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS vehicles (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(160) NOT NULL,
 type ENUM('Car','SUV','Truck','Van','Bike','Other') NOT NULL,
 brand VARCHAR(100) NOT NULL,
 model_year SMALLINT NOT NULL,
 location VARCHAR(120) NOT NULL,
 price_per_day DECIMAL(10,2) NOT NULL,
 seats INT NOT NULL DEFAULT 4,
 transmission VARCHAR(40) NOT NULL DEFAULT 'Manual',
 fuel VARCHAR(40) NOT NULL DEFAULT 'Petrol',
 description TEXT NOT NULL,
 image VARCHAR(255) DEFAULT NULL,
 available TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS bookings (
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL,
 vehicle_id INT DEFAULT NULL,
 customer_name VARCHAR(120) NOT NULL,
 customer_phone VARCHAR(25) NOT NULL,
 address TEXT NOT NULL,
 vehicle_name VARCHAR(160) NOT NULL,
 vehicle_type VARCHAR(40) NOT NULL,
 location VARCHAR(120) NOT NULL,
 start_date DATE NOT NULL,
 end_date DATE NOT NULL,
 appointment_at DATETIME DEFAULT NULL,
 total_amount DECIMAL(12,2) NOT NULL,
 status ENUM('Pending','Approved','Rejected','Checked-in','Completed','Cancelled') NOT NULL DEFAULT 'Pending',
 checkin_notes TEXT DEFAULT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (user_id) REFERENCES users(id),
 FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS reviews (
 id INT AUTO_INCREMENT PRIMARY KEY,
 booking_id INT NOT NULL UNIQUE,
 user_id INT NOT NULL,
 vehicle_id INT DEFAULT NULL,
 rating TINYINT NOT NULL,
 review TEXT NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE SET NULL
);

INSERT INTO vehicles(name,type,brand,model_year,location,price_per_day,seats,transmission,fuel,description,available)
SELECT 'City Comfort Sedan','Car','Example Motors',2023,'Chennai',2200,5,'Automatic','Petrol','Comfortable sedan for city travel and weekend trips.',1
WHERE NOT EXISTS (SELECT 1 FROM vehicles WHERE name='City Comfort Sedan');
INSERT INTO vehicles(name,type,brand,model_year,location,price_per_day,seats,transmission,fuel,description,available)
SELECT 'Adventure SUV','SUV','Example Motors',2024,'Chennai',3800,7,'Automatic','Diesel','Spacious SUV for family travel and longer journeys.',1
WHERE NOT EXISTS (SELECT 1 FROM vehicles WHERE name='Adventure SUV');
INSERT INTO vehicles(name,type,brand,model_year,location,price_per_day,seats,transmission,fuel,description,available)
SELECT 'Utility Pickup','Truck','Example Motors',2022,'Coimbatore',3200,2,'Manual','Diesel','Practical pickup truck for moving equipment and goods.',1
WHERE NOT EXISTS (SELECT 1 FROM vehicles WHERE name='Utility Pickup');
