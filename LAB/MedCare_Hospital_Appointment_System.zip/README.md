# MedCare Hospital Appointment Booking System

## Run
1. Extract the ZIP archive.
2. Open `index.html` in a modern browser.
3. Register a patient account to book appointments.

## Demo hospital manager
Email: `manager@medcare.demo`
Password: `medcare123`

## Features
- Patient signup, login and profile
- Search doctors by name, specialty, hospital and location
- Hospital directory and Google Maps links
- Appointment booking by doctor, date and available time
- Monthly calendar and occupied-slot checks
- Cancel and reschedule appointments
- Appointment history and status
- Patient check-in form and check-in history
- Doctor ratings and feedback
- Hospital registration and profile updates
- Admin appointment statistics and management
- Add doctors and manage appointment status
- Responsive desktop and mobile layout

## Technology
HTML5, CSS3, JavaScript and browser LocalStorage.

## Important
This is a frontend educational lab prototype. Data is stored locally in the browser. Real email/SMS reminders, secure authentication, healthcare-compliant data storage, multi-user real-time scheduling and live payment processing require a secure backend and provider integrations. No real payment is collected. Do not enter sensitive medical information.
