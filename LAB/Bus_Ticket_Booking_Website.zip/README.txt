ROUTE — BUS TICKET BOOKING WEBSITE
==================================
HOW TO RUN
1. Extract Bus_Ticket_Booking_Website.zip.
2. Open index.html in Chrome or Edge.
3. Search a route, select a date and passenger count, choose seats, enter passenger details, and complete the simulated checkout.

DEMO ADMIN
Email: admin@route.com
Password: admin123

FEATURES
- Responsive bus booking UI
- Route/date/passenger search, bus categories and sorting
- Seat selection with booked-seat blocking per bus/date
- Passenger details and simulated checkout
- Booking reference, booking history, modify/cancel booking
- Registration, login, admin panel, bus CRUD
- Registered user list, booking management, comments/reviews
- Contact form and downloadable CSV report

DEMO RULES
- Booking changes and cancellation are permitted only at least 3 days before departure for users.
- Payments are simulated; no real payment is taken.
- Data is saved in browser localStorage for this browser only.
- Confirmation is displayed on screen; actual email delivery requires a backend service.

IMPORTANT
This is a front-end academic lab demo, not a production ticketing service. Do not use real passwords or payment information. Production use requires a backend/database, secure authentication, server-side seat locking, payment gateway, and email provider.
