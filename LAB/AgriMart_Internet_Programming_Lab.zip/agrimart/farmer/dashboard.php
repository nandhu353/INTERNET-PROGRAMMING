<?php
require_once '../includes/functions.php';$u=require_role('farmer');$page_title='Farmer dashboard';$base='../';
$s=$pdo->prepare("SELECT COUNT(*) FROM products WHERE farmer_id=?");$s->execute([$u['id']]);$count=$s->fetchColumn();
$s=$pdo->prepare("SELECT COALESCE(SUM(oi.quantity*oi.unit_price),0) FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE oi.farmer_id=? AND o.order_status<>'Cancelled'");$s->execute([$u['id']]);$sales=$s->fetchColumn();
$s=$pdo->prepare("SELECT COUNT(DISTINCT oi.order_id) FROM order_items oi WHERE oi.farmer_id=?");$s->execute([$u['id']]);$orders=$s->fetchColumn();
require '../includes/header.php';?>
<h1>Farmer dashboard</h1><p class="muted">Welcome, <?=e($u['name'])?>. Manage your catalogue, sales and shipments.</p><div class="stats"><div class="panel stat"><strong><?=$count?></strong>Products listed</div><div class="panel stat"><strong><?=money($sales)?></strong>Total sales</div><div class="panel stat"><strong><?=$orders?></strong>Orders received</div></div>
<div class="actions" style="margin:22px 0"><a class="btn" href="product_form.php">＋ Add product</a><a class="btn secondary" href="products.php">Manage products</a><a class="btn secondary" href="sales.php">My sales & shipping</a></div>
<?php require '../includes/footer.php'; ?>
