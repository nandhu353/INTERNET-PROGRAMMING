ReNewMarket - Second-hand goods marketplace demo

HOW TO RUN
1. Extract ReNewMarket.zip.
2. Open index.html in Chrome, Edge, Firefox, or another modern browser.
3. No installation or server is required.

ADMIN LOGIN
Email: admin@renewmarket.com
Password: admin123

DEMO BUYER
Email: buyer@example.com
Password: buyer123

FEATURES
- User registration and login
- Marketplace search, category filtering and price sorting
- Item listing creation with optional photo URL
- Item details and order request
- Admin User Management: edit and delete users
- Admin Category Management: add and delete categories
- Admin Commodity Management: edit and delete listings
- Admin Order Management: change order status to Shipped or Received; delete orders
- Data is stored in the browser using localStorage.

IMPORTANT
This is a front-end demonstration project. It does not include a real backend, shared database,
production authentication, payment gateway, email service, or actual shipping integration.
For a real deployment, connect it to a backend API and database and implement secure payments.
