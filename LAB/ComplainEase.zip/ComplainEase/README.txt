COMPLAINEASE - INTERNET PROGRAMMING LAB PROJECT

HOW TO RUN
1. Extract ComplainEase.zip.
2. Open index.html in a modern browser.
3. No installation or server required.

DEMO LOGIN
Admin: admin@complainease.com / admin123
Officer: officer@complainease.com / officer123
User: user@example.com / user123

USER MODULE
- Register and login
- Post complaint with category, description, address, Google Maps URL and proof URL
- View complaint ID, status and history
- Submit feedback
- View administrator contact information

OFFICER MODULE
- Officer login
- View complaints
- Update complaint status
- Add proof-of-work URL

ADMIN MODULE
- View all complaints and accounts
- Create officer account and generate login credentials
- Delete accounts
- Change account passwords
- Access officer accounts
- Update OES information
- Delete complaints

TECHNOLOGIES
HTML, CSS, JavaScript, LocalStorage

IMPORTANT
This is a frontend lab demonstration. Data is stored in the current browser using LocalStorage.
It does not include a real backend/database, email/SMS notifications, file uploads, Google Maps API,
or secure server-side authentication. Location can be entered as an address or Google Maps URL.
For production, connect a backend, database, map service and notification provider.
