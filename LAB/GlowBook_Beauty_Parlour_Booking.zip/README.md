# GlowBook – Beauty Parlour Appointment Booking System

## Run the project
1. Extract `GlowBook_Beauty_Parlour_Booking.zip`.
2. Open `index.html` in Chrome, Edge or Firefox.
3. Register a customer account and book an appointment.

## Demo manager credentials
- Username: `manager`
- Password: `glow123`

## Included modules
- Customer registration, login and personal account page
- Browse beauty services and stylist profiles
- Appointment booking by service, stylist, date and available time
- Monthly reservations calendar with unavailable dates / locked slots
- Create, reschedule and cancel reservations
- Upcoming and past appointment history
- Full payment, 30% deposit or pay-at-salon selection
- Demo Stripe, PayPal, UPI and card payment method choices
- Salon manager dashboard and reservation overview
- Manager cancellation and completion status
- Lock / unlock stylist time slots
- Call customer using the phone link
- Customer feedback and suggestions
- Add new salon services
- Responsive desktop and mobile interface

## Technologies
HTML5, CSS3, JavaScript and browser LocalStorage.

## Important notes
This is a front-end educational lab prototype. Appointment, account and service data is stored in browser LocalStorage. Payments are simulated; Stripe and PayPal are labels for demonstration only and do not charge money. Real payment processing, SMS/email reminders, password reset, secure authentication and multi-device real-time availability require a backend server and approved provider integrations. The automatic unpaid-booking cancellation policy is not implemented as a live scheduled server task in this frontend-only demo. Do not enter real payment details.
