<?php
if(session_status()===PHP_SESSION_NONE) session_start();
require_once __DIR__.'/../config/database.php';
function e($v): string { return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8'); }
function go(string $url): never { header("Location: $url"); exit; }
function csrf_token(): string { if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function csrf_field(): string { return '<input type="hidden" name="csrf" value="'.e(csrf_token()).'">'; }
if($_SERVER['REQUEST_METHOD']==='POST'&&!hash_equals($_SESSION['csrf']??'',$_POST['csrf']??'')){http_response_code(419);exit('Invalid request token. Refresh and try again.');}
function flash(string $m,string $t='success'): void { $_SESSION['flash']=['m'=>$m,'t'=>$t]; }
function show_flash(): void { if(isset($_SESSION['flash'])){$f=$_SESSION['flash'];unset($_SESSION['flash']);echo '<div class="alert '.e($f['t']).'">'.e($f['m']).'</div>';}}
function money($n): string { return '₹'.number_format((float)$n,2); }
function user(): ?array { return $_SESSION['user']??null; }
function need_user(): array { if(!user())go('login.php');if(empty($_SESSION['user']['is_verified']))go('verify.php');return user(); }
function need_admin(): array { $u=need_user();if($u['role']!=='admin')go('../index.php');return $u; }
function refresh_user(PDO $pdo): void { if(user()){$s=$pdo->prepare("SELECT id,name,email,phone,role,is_verified FROM users WHERE id=?");$s->execute([user()['id']]);$_SESSION['user']=$s->fetch();}}
function otp_create(PDO $pdo,int $id): string { $code=(string)random_int(100000,999999);$pdo->prepare("UPDATE users SET otp_hash=?,otp_expires_at=? WHERE id=?")->execute([password_hash($code,PASSWORD_DEFAULT),date('Y-m-d H:i:s',time()+300),$id]);$_SESSION['demo_otp']=$code;return $code; }
function image_upload(string $field): ?string { if(empty($_FILES[$field]['name']))return null;$f=$_FILES[$field];if($f['error']!==UPLOAD_ERR_OK||$f['size']>3*1024*1024)throw new RuntimeException('Image must be under 3 MB.');$mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);$types=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];if(!isset($types[$mime]))throw new RuntimeException('Upload JPG, PNG or WEBP only.');$n=bin2hex(random_bytes(12)).'.'.$types[$mime];if(!move_uploaded_file($f['tmp_name'],__DIR__.'/../uploads/'.$n))throw new RuntimeException('Image upload failed.');return $n; }
