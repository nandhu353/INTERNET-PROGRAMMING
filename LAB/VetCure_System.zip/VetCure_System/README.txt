VETCURE - Veterinary Consultation and Animal Disease Management System

TECHNOLOGY:
- PHP 8+
- MySQL
- HTML, CSS, JavaScript
- Run using XAMPP (Apache + MySQL)

SETUP:
1. Extract the ZIP file into: C:\xampp\htdocs\
2. Start Apache and MySQL in XAMPP.
3. Open phpMyAdmin: http://localhost/phpmyadmin
4. Create/import the database by importing database.sql.
5. Check config.php and update DB username/password if required.
   Default XAMPP settings: username=root, password=(blank).
6. Open: http://localhost/vetcure_system/

DEMO ACCOUNTS:
- Create a farmer account using Register.
- Create a doctor account using Register and select Doctor role.
- For a quick demo, register both accounts yourself.

IMPORTANT:
- This is an academic/demo project.
- Payments are recorded as payment requests (bank transfer or EasyPaisa).
  No real money is transferred and no live payment gateway is connected.
- Uploaded media is stored in uploads/complaints/.
- A veterinarian must verify symptoms and prescribe treatment. Sample cure
  information is educational and must not replace professional diagnosis.
