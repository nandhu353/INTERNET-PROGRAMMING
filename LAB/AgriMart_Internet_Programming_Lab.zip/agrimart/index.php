<?php
require_once 'includes/functions.php';
$page_title='AgriMart | Home'; $base='';
$q=trim($_GET['q']??''); $cat=trim($_GET['category']??'');
$sql="SELECT p.*,u.name farmer_name FROM products p JOIN users u ON u.id=p.farmer_id WHERE p.stock>0";
$args=[];
if($q!==''){$sql.=" AND (p.name LIKE ? OR p.description LIKE ?)";$args[]="%$q%";$args[]="%$q%";}
if($cat!==''){$sql.=" AND p.category=?";$args[]=$cat;}
$sql.=" ORDER BY p.created_at DESC";
$s=$pdo->prepare($sql);$s->execute($args);$products=$s->fetchAll();
$cats=$pdo->query("SELECT DISTINCT category FROM products ORDER BY category")->fetchAll(PDO::FETCH_COLUMN);
require 'includes/header.php';
?>
<section class="hero"><h1>Grow better with AgriMart 🌾</h1><p>Your online marketplace for quality seeds, fertilizers, pesticides, farming equipment and essential tools. Shop trusted agricultural supplies from farmers and sellers.</p><div class="actions"><a class="btn" href="#products">Explore products</a><?php if(!current_user()): ?><a class="btn secondary" href="register.php">Join AgriMart</a><?php endif; ?></div></section>
<h2 id="products">Agricultural products</h2>
<form class="searchbar" method="get"><input name="q" placeholder="Search seeds, tools, fertilizers..." value="<?=e($q)?>"><select name="category"><option value="">All categories</option><?php foreach($cats as $c):?><option <?= $cat===$c?'selected':'' ?>><?=e($c)?></option><?php endforeach;?></select><button>Search</button></form>
<div class="grid"><?php foreach($products as $p):?><article class="card">
<?php if($p['image']):?><img class="product-img" src="uploads/<?=e($p['image'])?>" alt="<?=e($p['name'])?>"><?php else:?><div class="placeholder">🌱</div><?php endif;?>
<h3><?=e($p['name'])?></h3><span class="tag"><?=e($p['category'])?></span><p class="price"><?=money($p['price'])?></p><p class="muted">Seller: <?=e($p['farmer_name'])?> · <?= (int)$p['stock']?> in stock</p><a class="btn" href="product.php?id=<?=(int)$p['id']?>">View details</a></article><?php endforeach;?>
<?php if(!$products):?><p>No products found. Try another search or category.</p><?php endif;?></div>
<?php require 'includes/footer.php'; ?>
