EASYTOLL - Online Toll Payment System (Frontend Lab Project)

HOW TO RUN
1. Extract EasyToll.zip.
2. Open index.html in Chrome, Edge or Firefox.
3. No installation is required.

DEMO ACCOUNTS
Admin: admin@easytoll.com / admin123
User: user@example.com / user123
Toll Gate: gate@easytoll.com / gate123

FUNCTIONAL MODULES
ADMIN
- Admin login
- Manage/edit/delete users
- View and approve toll pass applications
- Generate/view pass QR codes
- Create and delete toll gate details
- Create toll gate login account
- View eTickets

USER
- Register and login
- Add money to eWallet (demo)
- Add/delete vehicle details
- Buy toll eTicket using wallet balance
- Apply for new toll pass and renew pass
- View pass QR code
- View transaction/ticket history

TOLL GATE USER
- Login
- Verify QR/pass/ticket code
- Verify approved pass or paid eTicket
- Update current toll location

IMPORTANT LIMITATIONS
This is a frontend demonstration using HTML, CSS, JavaScript and browser LocalStorage.
It does not connect to a real bank/payment gateway, live QR scanner/camera, GPS, backend server,
or shared database. The QR symbol is a demonstration placeholder; codes can be typed into
the toll gate verification screen. For production, implement a secure backend, database,
real QR generation/scanning, authentication and payment gateway integration.
