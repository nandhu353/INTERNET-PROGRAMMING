<?php
require_once 'includes/functions.php';$u=require_login();$page_title='My account';$base='';
if($_SERVER['REQUEST_METHOD']==='POST'){$name=trim($_POST['name']??'');$phone=trim($_POST['phone']??'');if(!$name||!preg_match('/^[0-9+\-\s]{8,20}$/',$phone))flash('Enter a valid name and phone number.','error');else{$pdo->prepare("UPDATE users SET name=?,phone=? WHERE id=?")->execute([$name,$phone,$u['id']]);refresh_user($pdo);flash('Account updated.');redirect('account.php');}}
require 'includes/header.php';?>
<div class="form-wrap panel"><h1>My account</h1><p><span class="tag"><?=e(ucfirst($u['role']))?></span></p><form method="post"><?=csrf_field()?><label>Name<input name="name" value="<?=e($u['name'])?>" required></label><label>Email<input value="<?=e($u['email'])?>" disabled></label><label>Phone<input name="phone" value="<?=e($u['phone'])?>" required></label><?php if($u['role']==='customer'):?><p>Wallet balance: <strong><?=money($u['wallet'])?></strong></p><?php endif;?><button>Update account</button></form></div>
<?php require 'includes/footer.php'; ?>
