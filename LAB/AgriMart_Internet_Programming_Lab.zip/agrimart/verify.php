<?php
require_once 'includes/functions.php';$page_title='OTP verification';$base='';
$id=(int)($_SESSION['pending_user']??0);if(!$id)redirect('login.php');
if($_SERVER['REQUEST_METHOD']==='POST'){
$otp=trim($_POST['otp']??'');$s=$pdo->prepare("SELECT * FROM users WHERE id=?");$s->execute([$id]);$u=$s->fetch();
if($u&&$u['otp_hash']&&strtotime($u['otp_expires_at'])>=time()&&password_verify($otp,$u['otp_hash'])){
$pdo->prepare("UPDATE users SET is_verified=1,otp_hash=NULL,otp_expires_at=NULL WHERE id=?")->execute([$id]);unset($_SESSION['pending_user'],$_SESSION['demo_otp']);$s=$pdo->prepare("SELECT id,name,email,phone,role,is_verified,wallet FROM users WHERE id=?");$s->execute([$id]);$_SESSION['user']=$s->fetch();flash('Your account is verified. Welcome to AgriMart!');redirect($_SESSION['user']['role']==='farmer'?'farmer/dashboard.php':'index.php');
}else flash('Incorrect or expired OTP. Log in again to generate a new one.','error');
}
require 'includes/header.php';?>
<div class="form-wrap panel"><h1>OTP verification</h1><p>Enter the six-digit code generated for your account. For this lab build, the demo OTP is shown below.</p><?php if(isset($_SESSION['demo_otp'])):?><div class="alert info">Demo OTP: <strong><?=e($_SESSION['demo_otp'])?></strong> (valid for 5 minutes)</div><?php endif;?><form method="post"><?=csrf_field()?><label>One-time password<input name="otp" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" required></label><button>Verify account</button></form></div>
<?php require 'includes/footer.php'; ?>
