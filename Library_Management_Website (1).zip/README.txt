LIBRA — COLLEGE LIBRARY MANAGEMENT WEBSITE (DEMO)

RUN
1. Extract Library_Management_Website.zip.
2. Open the folder and double-click index.html in Chrome or Edge.
3. Internet is used for Google Fonts; the interface and demo features run locally.

DEMO LIBRARIAN LOGIN
Email: admin@libra.com
Password: admin123

FEATURES
Student: register/login, search and view books, request a book, view borrowing history and issue/due dates, check fines, filter/download study materials by academic year and semester, edit profile, contact form.
Librarian: login, add/update/delete books, issue/approve/return books, calculate and update fines, manage study materials by year/semester, view registered students and contact messages.
Fine rule: ₹5 per overdue day. Default loan period: 14 days.

IMPORTANT LIMITATIONS
This is an academic front-end demo. Data is stored in the browser localStorage, so it is not shared across devices or users. Authentication is not secure and is not suitable for real personal data. Study material downloads are demo text placeholders unless the librarian provides a direct resource URL. For production, implement a backend API and database, secure password hashing, role-based authorization, real file storage, and server-side fine calculations.

Files:
- index.html: page structure
- style.css: responsive styling
- app.js: demo application logic
