<?php
require_once 'includes/functions.php';$page_title='Login';$base='';
if($_SERVER['REQUEST_METHOD']==='POST'){
$email=strtolower(trim($_POST['email']??''));$pw=$_POST['password']??'';
$s=$pdo->prepare("SELECT * FROM users WHERE email=?");$s->execute([$email]);$u=$s->fetch();
if($u&&password_verify($pw,$u['password_hash'])){$_SESSION['pending_user']=(int)$u['id'];$otp=create_otp($pdo,(int)$u['id']);flash("Demo OTP: $otp",'info');redirect('verify.php');}
else flash('Invalid email or password.','error');
}
require 'includes/header.php';?>
<div class="form-wrap panel"><h1>Login</h1><form method="post"><?=csrf_field()?><label>Email<input type="email" name="email" required></label><label>Password<input type="password" name="password" required></label><button>Login and get OTP</button></form><p class="muted">New to AgriMart? <a href="register.php">Register here</a>.</p></div>
<?php require 'includes/footer.php'; ?>
