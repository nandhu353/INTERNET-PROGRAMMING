CREATE DATABASE IF NOT EXISTS vetcure CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE vetcure;

CREATE TABLE users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 email VARCHAR(150) NOT NULL UNIQUE,
 phone VARCHAR(30),
 password VARCHAR(255) NOT NULL,
 role ENUM('farmer','doctor') NOT NULL,
 clinic_type ENUM('government','private') DEFAULT NULL,
 specialization VARCHAR(150),
 bank_details VARCHAR(255),
 easypaisa_details VARCHAR(100),
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE subscriptions (
 id INT AUTO_INCREMENT PRIMARY KEY,
 farmer_id INT NOT NULL,
 doctor_type ENUM('government','private') NOT NULL,
 status ENUM('free','pending','active') DEFAULT 'pending',
 amount DECIMAL(10,2) DEFAULT 0,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (farmer_id) REFERENCES users(id)
);

CREATE TABLE complaints (
 id INT AUTO_INCREMENT PRIMARY KEY,
 farmer_id INT NOT NULL,
 animal_name VARCHAR(100),
 animal_type VARCHAR(100),
 area VARCHAR(150),
 symptoms TEXT NOT NULL,
 media_path VARCHAR(255),
 media_type VARCHAR(30),
 status ENUM('Pending','Responded','Closed') DEFAULT 'Pending',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (farmer_id) REFERENCES users(id)
);

CREATE TABLE solutions (
 id INT AUTO_INCREMENT PRIMARY KEY,
 complaint_id INT NOT NULL,
 doctor_id INT NOT NULL,
 diagnosis VARCHAR(255),
 prescription TEXT NOT NULL,
 advice TEXT,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (complaint_id) REFERENCES complaints(id),
 FOREIGN KEY (doctor_id) REFERENCES users(id)
);

CREATE TABLE cures (
 id INT AUTO_INCREMENT PRIMARY KEY,
 disease_name VARCHAR(150) NOT NULL,
 animal_type VARCHAR(100),
 symptoms TEXT,
 basic_advice TEXT,
 prescription_note TEXT,
 image_path VARCHAR(255),
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE news (
 id INT AUTO_INCREMENT PRIMARY KEY,
 doctor_id INT NOT NULL,
 title VARCHAR(200) NOT NULL,
 content TEXT NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (doctor_id) REFERENCES users(id)
);

CREATE TABLE payments (
 id INT AUTO_INCREMENT PRIMARY KEY,
 farmer_id INT NOT NULL,
 doctor_id INT,
 method ENUM('Bank Transfer','EasyPaisa') NOT NULL,
 amount DECIMAL(10,2) NOT NULL,
 reference_no VARCHAR(100),
 status ENUM('Pending','Verified','Rejected') DEFAULT 'Pending',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (farmer_id) REFERENCES users(id),
 FOREIGN KEY (doctor_id) REFERENCES users(id)
);

CREATE TABLE feedback (
 id INT AUTO_INCREMENT PRIMARY KEY,
 farmer_id INT NOT NULL,
 message TEXT NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (farmer_id) REFERENCES users(id)
);

INSERT INTO cures (disease_name, animal_type, symptoms, basic_advice, prescription_note) VALUES
('Foot and Mouth Disease','Cattle','Fever, mouth blisters, excessive salivation, foot lesions','Isolate the affected animal and contact a veterinarian quickly.','Treatment and medication must be prescribed by a qualified veterinarian.'),
('Mastitis','Cattle','Swollen udder, pain, abnormal milk, fever','Maintain hygiene and seek veterinary examination.','Do not use antibiotics without veterinary guidance.'),
('Canine Parvovirus','Dog','Vomiting, diarrhoea, weakness, loss of appetite','Urgent veterinary care and isolation are important.','Requires professional diagnosis and supportive treatment.');
