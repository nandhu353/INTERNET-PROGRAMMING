<?php $user=current_user(); ?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($page_title ?? 'AgriMart') ?></title><link rel="stylesheet" href="<?= e($base ?? '') ?>assets/style.css"></head><body>
<header class="topbar"><a class="brand" href="<?= e($base ?? '') ?>index.php">🌱 AgriMart</a>
<nav><a href="<?= e($base ?? '') ?>index.php">Home</a>
<?php if($user): ?>
<?php if($user['role']==='farmer'): ?><a href="<?= e($base ?? '') ?>farmer/dashboard.php">Farmer Dashboard</a><?php else: ?><a href="<?= e($base ?? '') ?>cart.php">Cart</a><a href="<?= e($base ?? '') ?>orders.php">My Orders</a><a href="<?= e($base ?? '') ?>wallet.php">Wallet</a><?php endif; ?>
<a href="<?= e($base ?? '') ?>account.php">My Account</a><a href="<?= e($base ?? '') ?>logout.php">Logout</a>
<?php else: ?><a href="<?= e($base ?? '') ?>register.php">Register</a><a href="<?= e($base ?? '') ?>login.php">Login</a><?php endif; ?></nav></header>
<main class="container"><?php show_flash(); ?>
