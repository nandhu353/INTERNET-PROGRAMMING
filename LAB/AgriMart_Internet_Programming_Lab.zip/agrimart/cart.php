<?php
require_once 'includes/functions.php';$u=require_role('customer');$page_title='Shopping cart';$base='';
$cart=$_SESSION['cart']??[];
if($_SERVER['REQUEST_METHOD']==='POST'){
if(isset($_POST['remove']))unset($cart[(int)$_POST['remove']]);
elseif(isset($_POST['update'])){foreach(($_POST['qty']??[]) as $id=>$qty){$id=(int)$id;$qty=max(1,(int)$qty);$s=$pdo->prepare("SELECT stock FROM products WHERE id=?");$s->execute([$id]);$stock=$s->fetchColumn();if($stock===false)unset($cart[$id]);else $cart[$id]=min($qty,(int)$stock);}}
$_SESSION['cart']=$cart;flash('Cart updated.');redirect('cart.php');
}
$items=[];$total=0;foreach($cart as $id=>$qty){$s=$pdo->prepare("SELECT * FROM products WHERE id=? AND stock>0");$s->execute([$id]);if($p=$s->fetch()){$p['quantity']=$qty;$p['subtotal']=$qty*$p['price'];$items[]=$p;$total+=$p['subtotal'];}}
require 'includes/header.php';?>
<h1>Your shopping cart</h1><?php if(!$items):?><div class="panel">Your cart is empty. <a href="index.php">Browse products</a>.</div><?php else:?><form method="post"><?=csrf_field()?><div class="table-wrap"><table><tr><th>Product</th><th>Price</th><th>Quantity</th><th>Subtotal</th><th>Action</th></tr><?php foreach($items as $p):?><tr><td><?=e($p['name'])?></td><td><?=money($p['price'])?></td><td><input data-qty type="number" name="qty[<?=$p['id']?>]" min="1" max="<?=$p['stock']?>" value="<?=$p['quantity']?>" style="width:85px"></td><td><?=money($p['subtotal'])?></td><td><button class="danger" name="remove" value="<?=$p['id']?>" formnovalidate>Remove</button></td></tr><?php endforeach;?></table></div><p class="price">Total: <?=money($total)?></p><div class="actions"><button name="update" value="1">Update cart</button><a class="btn" href="checkout.php">Proceed to checkout</a></div></form><?php endif;?>
<?php require 'includes/footer.php'; ?>
