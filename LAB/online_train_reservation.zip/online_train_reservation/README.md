# Online Train Reservation System (Starter Demo)

A responsive student-project starter with train search, demo seat availability, registration/login, ticket booking, PNR lookup, cancellation and a sample refund calculation.

## Requirements
- Node.js 18 or later
- npm

## Run
1. Extract the ZIP.
2. Open a terminal in the extracted `online_train_reservation` folder.
3. Run `npm install`
4. Run `npm start`
5. Open `http://localhost:3000`

## Demo routes
Try routes such as Chennai → Bengaluru, Chennai → Kochi, Bengaluru → Chennai, or Chennai → Hyderabad. Register an account before logging in. A successful booking returns a demo PNR.

## Important limitations
- This is an educational prototype, not an official railway booking service.
- Data is stored in memory and resets when the server restarts; it is not connected to a database.
- Login is a basic demonstration and does not use production-grade password hashing or sessions.
- No real payment gateway, email delivery, official railway inventory, or real PNR verification is connected.
- The 80% refund is a sample rule only. Do not use it for real bookings or payments.

## Suggested next steps
For a production-style college project, add a database (MySQL/PostgreSQL), password hashing, secure sessions, admin authentication, payment provider sandbox integration, email service, input validation, and automated tests.
