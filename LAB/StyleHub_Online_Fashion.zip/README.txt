STYLEHUB ONLINE FASHION SHOPPING WEBSITE
=========================================

HOW TO RUN
1. Extract StyleHub_Online_Fashion.zip.
2. Open index.html in Chrome, Edge or Firefox.
3. No installation is required.

FEATURES
- Fashion catalogue for clothing, footwear and accessories.
- Men, women and kids audience filters.
- Categories and subcategories on home page.
- Search, category, stock and price filtering.
- Product details, ratings and customer reviews.
- Shopping cart: add, edit quantity and remove products.
- Wishlist.
- User registration/login and logout.
- Checkout with delivery address and demo payment selection.
- Order history and order status tracking.
- Admin can add/remove products, update price and description.
- Admin can view customer checkout details and update order statuses.
- Responsive layout for mobile and desktop.

ADMIN DEMO LOGIN
Email: admin@stylehub.demo
Password: admin123
To open the admin login, click the StyleHub footer brand five times.

TECHNOLOGIES
HTML, CSS, JavaScript and browser LocalStorage.

IMPORTANT
This is an Internet Programming lab frontend prototype. Data is stored in
the current browser using LocalStorage. Login is a demonstration and is not
secure authentication. Payment options are simulated; no real payment is
processed. A production site requires a backend, database, secure password
handling, payment gateway, server-side stock validation and email/SMS services.
Do not enter real payment details or sensitive personal information.
