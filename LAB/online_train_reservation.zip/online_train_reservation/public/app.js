const $ = id => document.getElementById(id);
let currentTrains = [];
let selectedTrain = null;
const today = new Date();
$("date").min = today.toISOString().slice(0,10);
$("date").value = today.toISOString().slice(0,10);

async function request(url, options={}) {
  const response = await fetch(url, { headers: { "Content-Type": "application/json" }, ...options });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Something went wrong.");
  return data;
}
function message(id, text, type="") {
  const el = $(id); el.textContent = text; el.className = `notice ${type}`;
}
function toast(text) {
  $("toast").textContent = text; $("toast").classList.remove("hidden");
  setTimeout(() => $("toast").classList.add("hidden"), 3200);
}
function safe(text) {
  return String(text).replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
}
$("searchForm").addEventListener("submit", async e => {
  e.preventDefault();
  $("trainResults").innerHTML = '<p class="muted">Searching trains…</p>';
  try {
    const params = new URLSearchParams({from:$("from").value.trim(),to:$("to").value.trim()});
    currentTrains = await request("/api/trains?" + params);
    if (!currentTrains.length) { $("trainResults").innerHTML = '<p class="muted">No trains found for this route. Try Chennai, Bengaluru, Kochi or Hyderabad.</p>'; return; }
    $("trainResults").innerHTML = currentTrains.map(t => `
      <article class="train-card">
        <div><span class="train-number">TRAIN ${t.id}</span><h3>${safe(t.name)}</h3><p>${safe(t.from)} → ${safe(t.to)}</p></div>
        <div><span class="time">${safe(t.departure)}</span><p>Departure</p></div>
        <div><strong>${t.seats} seats</strong><p>${t.classes.map(safe).join(" · ")}</p><strong>From ₹${t.fare}</strong></div>
        <button class="primary" data-book="${t.id}">Book</button>
      </article>`).join("");
    $("bookDate").value = $("date").value;
  } catch(err) { $("trainResults").textContent = err.message; }
});
$("trainResults").addEventListener("click", e => {
  const id = e.target.dataset.book;
  if (!id) return;
  selectedTrain = currentTrains.find(t => t.id === Number(id));
  if (!selectedTrain) return;
  $("bookTrainId").value = selectedTrain.id;
  $("bookDate").value = $("date").value;
  $("travelClass").innerHTML = selectedTrain.classes.map(c => `<option>${safe(c)}</option>`).join("");
  $("farePreview").textContent = `Base fare: ₹${selectedTrain.fare} per passenger. Final fare shown is a demo estimate.`;
  $("bookingMessage").textContent = "";
  $("bookingModal").classList.remove("hidden");
});
$("closeBooking").onclick = () => $("bookingModal").classList.add("hidden");
$("seatCount").addEventListener("input", () => {
  if (selectedTrain) $("farePreview").textContent = `Estimated total: ₹${selectedTrain.fare * Math.max(1, Number($("seatCount").value)||1)} (demo fare; taxes not included).`;
});
$("bookingForm").addEventListener("submit", async e => {
  e.preventDefault();
  try {
    const booking = await request("/api/bookings", {method:"POST", body:JSON.stringify({
      passenger:$("passengerName").value.trim(), email:$("passengerEmail").value.trim(),
      trainId:$("bookTrainId").value, travelDate:$("bookDate").value,
      travelClass:$("travelClass").value, seats:Number($("seatCount").value)
    })});
    message("bookingMessage", `Booking confirmed! PNR: ${booking.pnr}. ${booking.trainName}, ${booking.travelDate}, ${booking.travelClass}. Total fare: ₹${booking.fare}.`, "success");
    toast("Demo booking confirmed");
    $("pnrInput").value = booking.pnr;
    $("cancelPnr").value = booking.pnr;
  } catch(err) { message("bookingMessage", err.message, "error"); }
});
$("pnrForm").addEventListener("submit", async e => {
  e.preventDefault();
  try {
    const b = await request("/api/bookings/" + encodeURIComponent($("pnrInput").value.trim()));
    message("pnrResult", `PNR ${b.pnr} · ${b.status} · ${b.passenger} · ${b.trainName} · ${b.from} to ${b.to} · ${b.travelDate} · ${b.travelClass} · ${b.seats} seat(s) · Fare ₹${b.fare}`, "success");
  } catch(err) { message("pnrResult", err.message, "error"); }
});
$("cancelForm").addEventListener("submit", async e => {
  e.preventDefault();
  if (!confirm("Cancel this demo booking?")) return;
  try {
    const result = await request("/api/cancel", {method:"POST",body:JSON.stringify({pnr:$("cancelPnr").value.trim()})});
    message("cancelResult", `${result.message} Refund estimate: ₹${result.refund}.`, "success");
  } catch(err) { message("cancelResult", err.message, "error"); }
});
$("loginToggle").onclick = () => $("account").classList.toggle("hidden");
$("closeAccount").onclick = () => $("account").classList.add("hidden");
$("registerForm").addEventListener("submit", async e => {
  e.preventDefault();
  try {
    const r = await request("/api/register",{method:"POST",body:JSON.stringify({name:$("regName").value.trim(),email:$("regEmail").value.trim(),password:$("regPassword").value})});
    message("accountMessage",r.message,"success");
  } catch(err) { message("accountMessage",err.message,"error"); }
});
$("loginForm").addEventListener("submit", async e => {
  e.preventDefault();
  try {
    const r = await request("/api/login",{method:"POST",body:JSON.stringify({email:$("loginEmail").value.trim(),password:$("loginPassword").value})});
    message("accountMessage",`Welcome, ${r.name}! You are logged in for this demo session.`,"success");
  } catch(err) { message("accountMessage",err.message,"error"); }
});
