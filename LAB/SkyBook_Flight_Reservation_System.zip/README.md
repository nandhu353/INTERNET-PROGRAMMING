# SkyBook – Online Flight Reservation System

## Run the project
1. Extract the ZIP file.
2. Open `index.html` in a modern web browser.
3. Search flights using the default route Chennai → Bengaluru, or add flights from the Admin panel.

## Demo credentials
- Admin username: `admin`
- Admin password: `admin123`
- Customer: use Login / Register to create a local demo account.

## Included lab experiment modules
- Administrator login and forgot-password demonstration
- Customer registration and login
- Search flights by origin, destination, date, class and passenger count
- Flight results with seat inventory
- Seat selection and passenger details
- Ticket payment demonstration
- My Ticket / booking history
- Cancel ticket and restore seat inventory
- Print ticket / e-ticket
- Customer feedback
- Admin flight schedule and seat inventory management
- Admin booking and revenue summary report
- Responsive desktop and mobile layout

## Important implementation notes
This is a front-end educational prototype. Data is stored in the browser's `localStorage`; clearing browser data will clear demo accounts, flights, bookings and feedback. The payment form is simulated and does not process or store real card details. Real-time airline Global Distribution System (GDS) inventory, secure authentication, password reset emails, confirmation emails, and real payment processing require a server-side backend and approved third-party integrations. Do not use real payment card details.

## Files
- `index.html` – page structure and forms
- `style.css` – responsive styling
- `app.js` – demo application logic
