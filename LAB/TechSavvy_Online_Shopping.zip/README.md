# TechSavvy Online Shopping Website

A responsive Internet Programming lab mini-project built with HTML, CSS and JavaScript.

## Run
1. Extract `TechSavvy_Online_Shopping.zip`.
2. Open `index.html` in Chrome, Edge or Firefox.
3. No installation or server is required.

## Main features
- Home page with popular product categories and subcategories.
- Product catalogue with search, category, stock and price filters.
- Product details, ratings and customer reviews.
- Shopping cart: add, change quantity and remove products.
- Wishlist.
- User registration/login and logout.
- Checkout with delivery address and demo payment method.
- Order history and order status tracking.
- Admin: add/delete products, update prices and descriptions, view customer checkout details, update order status.
- Responsive desktop and mobile design.

## Demo admin
- Email: `admin@techsavvy.demo`
- Password: `admin123`
- To open admin login, click the TechSavvy footer label five times.

## Notes
This is a frontend lab prototype. Data is stored in the browser's LocalStorage. Login is a demonstration only and is not secure authentication. Payment choices are simulated; no real payment is processed. A production application requires a backend, database, secure authentication, payment gateway integration, server-side inventory validation and email/SMS notifications.

Use the same browser to retain demo data. Clear browser site data to reset the application.
